<?php
include_once 'util.php';



class Menu{
    
    protected $text;
    protected $sessionId;
    protected $conn; // Database connection

    function __construct($text, $sessionId){
        $this->text = $text;
        $this->sessionId = $sessionId;

        // Establish a database connection
        $this->conn = new PDO("mysql:host=localhost;dbname=project1", "root", "");
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function mainMenuRegistered(){
        $response = "CON Welcome to Online Examination System\n";
        $response .= "1. Take quiz\n";
        $response .= "2. View score\n";
        echo $response;
    }

    public function mainMenuUnRegistered(){
        $response = "CON Welcome to Online Examination System\n";
        $response .= "1. Register\n";
        $response .=util::$GO_BACK . "Back \n";
        $response .=util::$GO_TO_MAIN_MENU ."main menu \n";
        echo $response;
    }

    public function menuRegister($textArray,$phoneNumber){
        $level = count($textArray);
        if ($level == 1) {
            echo "CON Welcome to Online Examination System Registration\n";
            echo "Enter your Name:";
        } 
        elseif ($level == 2) {
            echo "CON Enter your Gender (M/F):";
        } 
        elseif ($level == 3) {
            echo "CON Enter your Email:";
        } 
        elseif ($level == 4) {
            echo "CON Enter your College Name:";
        } 
        elseif ($level == 5) {
            echo "CON Enter your Mobile Number:";
        } 
        elseif ($level == 6) {
            echo "CON Enter your Password:";
        } 
        elseif ($level == 7) {
            $name = $textArray[1];
            $gender = strtoupper($textArray[2]);
            $email = $textArray[3];
            $college = $textArray[4];
            $mobile = $textArray[5];
            $password = md5($textArray[6]);

            $stmt = $this->conn->prepare("INSERT INTO user (name, gender, email, college, mob, password) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $gender, $email, $college, $mobile, $password]);
    
            if ($stmt->rowCount() > 0) {
                echo "END Registration successful. You can now login.";
            } else {
                echo "END Registration failed. Please try again.";
            }
        }
    }
    
    public function menuViewSchedule(){
      
        $stmt = $this->conn->query("SELECT * FROM exam_schedule");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $response = "CON Exam Schedule:\n";
        foreach($rows as $row) {
            $response .= $row['exam_date'] . " - " . $row['exam_name'] . "\n";
        }
        echo $response;
    }

    public function menuViewResults($studentID){
       
        $stmt = $this->conn->prepare("SELECT * FROM exam_results WHERE student_id = ?");
        $stmt->execute([$studentID]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $response = "CON Exam Results:\n";
        foreach($rows as $row) {
            $response .= "Exam: " . $row['exam_name'] . ", Score: " . $row['score'] . "\n";
        }
        echo $response;
    }

    public function isRegistered($phoneNumber){
        $stmt = $this->conn->prepare("SELECT * FROM user WHERE mob = ?");
        $stmt->execute([$phoneNumber]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            return true;
        } else {
            return false;
        }        
        
    }
    public function middleware($text){
        //remove entries for going back and going to the main menu
        return $this->goBack($this->goToMainMenu($text));
    }

    public function goBack($text){
        //1*4*5*1*98*2*1234
        $explodedText = explode("*",$text);
        while(array_search(Util::$GO_BACK, $explodedText) != false){
            $firstIndex = array_search(Util::$GO_BACK, $explodedText);
            array_splice($explodedText, $firstIndex-1, 2);
        }
        return join("*", $explodedText);
    }

    public function goToMainMenu($text){
        //1*4*5*1*99*2*1234*99
        $explodedText = explode("*",$text);
        while(array_search(Util::$GO_TO_MAIN_MENU, $explodedText) != false){
            $firstIndex = array_search(Util::$GO_TO_MAIN_MENU, $explodedText);
            $explodedText = array_slice($explodedText, $firstIndex + 1);
        }
        return join("*",$explodedText);
    }
    public function menuTakeExam($textArray,$phoneNumber) {
        $level = count($textArray);
        $lv=1;
        $lev=0;
        $lvv=0;
        if ($level == 1) {
            echo "CON Quiz List and Choose \n";
            $stmt = $this ->conn->prepare("SELECT * FROM quiz");
            $stmt->execute();
            $response='';
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                // Construct the response string
                echo $row['eid'].". " . $row['title'] . "\n";
            }
        } 
        elseif ($level == 2) {
            
            echo "CON Quiz Infor:";
            $eid=$textArray['1'];
            $stmt = $this ->conn->prepare("SELECT * FROM quiz where eid=eid");
            $stmt->execute();
            $response = '';
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                // Construct the response string
                echo $row['eid'].". " . $row['title'] . "\n";
                
            }
            echo "1. Start Now  \n";
            echo "2. Cancel \n";
            
            
        } else {
            
            if ($textArray[2] ==1) {
                $eid = $textArray['1'];
                $stmt = $this->conn->prepare("SELECT * FROM questions WHERE eid = :eid");
                $stmt->bindParam(':eid', $eid);
                $stmt->execute();
                
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $sl=array_slice($textArray,2);
                    $lev = count($sl);
                    $level=$sl;
                    $lvv=count($row);
                    $stmt2 = $this->conn->prepare("SELECT * FROM options WHERE  qid=:qid");
                    $stmt2->bindParam(':qid', $eid);
                    $stmt2->execute();
                    $eid++;
                    $response="";
                   
                        if ($lev==$lv) {
                           echo "CON Q.".$lv." ". $row["qns"]."\n";
                           $ab=1;
                           
                           while ($row2 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                            echo $ab. " .". $row2["option"]."\n";
                            
                            $ab++;
                            $lv++;
                           }
                           $response .=util::$GO_BACK . "Back \n";
                           $response .=util::$GO_TO_MAIN_MENU ."main menu \n";
                           echo $response;
                        }
                        
                        $lv++; 
                         
            }
        }

        }

    }
    
 
}
    

?>