<?php
include_once 'menu.php';
include_once("dbConnection.php");
include_once ('util.php');

function isNotRegistered($phoneNumber, $con) {
    $stmt = $con->prepare("SELECT COUNT(*) FROM user WHERE mob= ?");
    $stmt->bind_param('s', $phoneNumber); // Bind the parameter
    $stmt->execute();
    $stmt->bind_result($count); // Bind the result
    $stmt->fetch(); // Fetch the result into $count
    $stmt->close(); // Close the statement
    return $count == 0; 
}

// Check if 'from' and 'text' keys exist in the $_POST array
if(isset($_POST['from']) && isset($_POST['text'])) {
    $phoneNumber = $_POST['from'];
    $text = $_POST['text']; 

    $textArray = explode(" ", $text);

    if(isset($textArray[0]) && isset($textArray[1]) && isset($textArray[2]) && isset($textArray[3]) && isset($textArray[4]) && isset($textArray[5])) {
        $name = $textArray[0];
        $gender = $textArray[1];
        $college = $textArray[2];
        $email = $textArray[3];
        $mob= $textArray[4];
        $password = $textArray[5];

        if(isNotRegistered($phoneNumber, $con)) {
            $stmt = $con->prepare("INSERT INTO user (name, gender, college,email,mob,password) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param('ssssss', $name, $gender, $college, $email, $phoneNumber, $password);

            if ($stmt->execute()) {
                $result = $con->query("SELECT * FROM user WHERE name = '$name'");
                while($value = $result->fetch_assoc()) {
                    echo "END Thank you $name, you have been successfully registered!";
                }
            } else {
                echo "END Registration failed. Please try again later.";
            }
        } else {
            echo "END User is already registered.";
        }
    } else {
        // If name or password is missing in the SMS, prompt the user to provide both
        echo "END Your SMS must contain name and password.";
    }
} else {
    // If 'from' or 'text' keys are missing in the $_POST array, prompt the user to provide them
    echo "END Please provide 'from' and 'text' parameters.";
}
?>
